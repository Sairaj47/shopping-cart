module.exports = {
    database: 'mongodb://localhost/kidsor'
}